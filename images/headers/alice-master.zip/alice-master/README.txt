Alice Theme
=====

Alice is a very light-weight theme for Stargazer WordPress Theme, which is developed by Justin Tadlock. The parent theme is based on famous Hybrid Framework. 

Download and Support
===
You may download the latest version of the theme from here or the blog BlogSynthesis.com. 
